// Initialize the game state
let board = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'X';
let gameOver = false;

// Get DOM elements
const cells = document.querySelectorAll('.cell');
const status = document.getElementById('status');
const modal = document.getElementById('modal');
const modalContent = document.querySelector('.modal-content');
const closeModal = document.getElementById('close-modal');
const resetButton = document.getElementById('reset-btn');

// Add click event listeners to all the cells
cells.forEach((cell, index) => {
    cell.addEventListener('click', () => handleCellClick(index, cell));
});

// Handle cell click
function handleCellClick(index, cell) {
    if (gameOver || board[index] !== '') return; // Ignore if cell is already filled or game is over

    // Update the board
    board[index] = currentPlayer;

    // Update cell's visual state
    cell.textContent = currentPlayer;

    // Add the appropriate class for styling X and O
    if (currentPlayer === 'X') {
        cell.classList.add('x');
        cell.classList.remove('o');
    } else {
        cell.classList.add('o');
        cell.classList.remove('x');
    }

    // Check for winner or draw
    if (checkWinner()) {
        gameOver = true;
        showWinner(currentPlayer);
    } else if (board.every(cell => cell !== '')) {
        gameOver = true;
        showWinner('Draw');
    } else {
        // Switch player
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        status.textContent = `Player ${currentPlayer}'s Turn`;
    }
}

// Check for winner
function checkWinner() {
    const winningCombinations = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    return winningCombinations.some(combination => {
        const [a, b, c] = combination;
        return board[a] && board[a] === board[b] && board[a] === board[c];
    });
}

// Show winner or draw in a modal
function showWinner(winner) {
    if (winner === 'Draw') {
        modalContent.innerHTML = '<p>It\'s a draw!</p>';
    } else {
        modalContent.innerHTML = `<p>Player ${winner} wins!</p>`;
    }
    modal.style.display = 'flex'; // Show modal

    // Automatically restart the game after a short delay (3 seconds)
    setTimeout(() => {
        modal.style.display = 'none'; // Hide modal
        resetGame(); // Reset the game
    }, 3000); // 3 seconds delay
}

// Close the modal manually (for future improvements if desired)
closeModal.addEventListener('click', () => {
    modal.style.display = 'none'; // Hide modal
    resetGame(); // Reset the game
});

// Reset the game
resetButton.addEventListener('click', resetGame);

// Reset the game state
function resetGame() {
    board = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    gameOver = false;
    cells.forEach(cell => {
        cell.textContent = ''; // Clear the cells
        cell.classList.remove('x', 'o'); // Remove X and O classes
    });
    status.textContent = `Player ${currentPlayer}'s Turn`;
}
